package com.borron.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/** Nivel de "locura" de Borrón según la tinta acumulada (0 a 3). */
fun nivelDe(tinta: Int): Int = when {
    tinta < 2 -> 0
    tinta < 4 -> 1
    tinta < 6 -> 2
    else -> 3
}

/** Borrón: mancha de tinta animada con ojos que siguen tu dedo. */
class BorronView(contexto: Context) : View(contexto) {

    var tinta = 0
    private var mirada: Pair<Float, Float>? = null
    private var t = 0f
    private var ultimo = System.nanoTime()
    private val d = resources.displayMetrics.density

    private val relleno = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF0A0F3C.toInt(); style = Paint.Style.FILL
    }
    private val borde = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF000000.toInt(); style = Paint.Style.STROKE; strokeWidth = 2.5f * d
    }
    private val ojo = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFE8FFFF.toInt(); style = Paint.Style.FILL
    }
    private val brillo = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt(); style = Paint.Style.FILL
    }
    private val ruta = Path()

    /** Hace que los ojos miren hacia (x, y); null = mirar a su aire. */
    fun mirar(x: Float?, y: Float?) {
        mirada = if (x != null && y != null) Pair(x, y) else null
    }

    override fun onDraw(c: Canvas) {
        val ahora = System.nanoTime()
        t += (ahora - ultimo) / 1e9f
        ultimo = ahora

        val w = width.toFloat()
        val h = height.toFloat()
        val nivel = nivelDe(tinta)
        val radioBase = min(w / 4.4f, h / 3.8f)
        val cx = w / 2f
        val cy = h / 2f
        val k = 1f + 0.03f * min(tinta, 10)
        val puntos = 72

        ruta.reset()
        for (i in 0 until puntos) {
            val a = 2f * PI.toFloat() * i / puntos
            var r = radioBase * k * (1f + 0.07f * sin(2f * t + 3f * a + 1.3f))
            if (nivel >= 2) r += radioBase * 0.35f * max(0f, sin(3f * a + t * 1.5f)).pow(2)
            if (nivel >= 3) r += radioBase * 0.10f * sin(7f * a + t * 5f)
            val x = cx + r * cos(a) * 1.15f
            val y = cy + r * sin(a) * 0.85f
            if (i == 0) ruta.moveTo(x, y) else ruta.lineTo(x, y)
        }
        ruta.close()
        c.drawPath(ruta, relleno)
        c.drawPath(ruta, borde)

        val sep = radioBase * (0.42f + 0.07f * nivel)
        val rad = radioBase * (0.20f + 0.045f * nivel)
        val ey = cy - radioBase * 0.1f
        val (mx, my) = mirada ?: Pair(cx + sin(t * 0.7f) * radioBase, cy + cos(t * 0.5f) * radioBase * 0.3f)
        for (ex in floatArrayOf(cx - sep, cx + sep)) {
            val dx = mx - ex
            val dy = my - ey
            val dist = hypot(dx, dy).coerceAtLeast(1f)
            val m = min(rad * 0.35f, dist * 0.1f)
            val px = ex + dx / dist * m
            val py = ey + dy / dist * m
            c.drawCircle(px, py, rad, ojo)
            c.drawCircle(px, py, rad, borde)
            c.drawCircle(px - rad * 0.3f, py - rad * 0.35f, rad * 0.2f, brillo)
        }

        postInvalidateDelayed(33)
    }
}
