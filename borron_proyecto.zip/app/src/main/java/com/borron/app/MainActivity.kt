package com.borron.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var campoNombre: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val pad = (20 * d).toInt()

        val columna = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        columna.addView(TextView(this).apply {
            text = "BORRÓN ANTIVIRUS"
            textSize = 22f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })

        columna.addView(TextView(this).apply {
            textSize = 15f
            setPadding(0, pad / 2, 0, pad / 2)
            text = "Aviso antes de empezar\n\n" +
                "Borrón es una mancha de tinta que flota sobre tu pantalla, incluso " +
                "sobre otras apps. Para eso necesita el permiso \"Mostrar sobre otras " +
                "apps\", que tú activas en Ajustes.\n\n" +
                "Usa: el nombre que escribas, la hora, el nivel de batería y la vibración.\n\n" +
                "No usa internet, cámara, micrófono, contactos ni archivos. No ve lo que " +
                "haces en otras apps y no guarda nada más que tu nombre en este teléfono.\n\n" +
                "Para despedirlo: mantén presionado a Borrón, usa el botón \"Cerrar a " +
                "Borrón\" de la notificación o el botón de abajo."
        })

        campoNombre = EditText(this).apply {
            hint = "Tu nombre"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
            setSingleLine(true)
            setText(getSharedPreferences("borron", MODE_PRIVATE).getString("nombre", ""))
        }
        columna.addView(campoNombre)

        columna.addView(Button(this).apply {
            text = "Despertar a Borrón"
            setOnClickListener { despertar() }
        })
        columna.addView(Button(this).apply {
            text = "Despedir a Borrón"
            setOnClickListener {
                stopService(Intent(this@MainActivity, OverlayService::class.java))
                Toast.makeText(this@MainActivity, "Borrón se fue... por ahora.", Toast.LENGTH_SHORT).show()
            }
        })

        setContentView(
            ScrollView(this).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT,
                )
                addView(columna)
            },
        )
    }

    private fun despertar() {
        val nombre = campoNombre.text.toString().trim().ifEmpty { "amigo" }
        getSharedPreferences("borron", MODE_PRIVATE).edit().putString("nombre", nombre).apply()

        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(
                this,
                "Activa \"Mostrar sobre otras apps\" para Borrón y vuelve a tocar Despertar.",
                Toast.LENGTH_LONG,
            ).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")),
            )
            return
        }

        // La notificación permite cerrar a Borrón desde cualquier lado.
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        startForegroundService(Intent(this, OverlayService::class.java))
        Toast.makeText(this, "Borrón despertó. Mantenlo presionado para despedirlo.", Toast.LENGTH_LONG).show()
        moveTaskToBack(true)
    }
}
