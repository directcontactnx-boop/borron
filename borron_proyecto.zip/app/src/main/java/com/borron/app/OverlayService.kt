package com.borron.app

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.Toast
import java.util.Calendar
import java.util.Locale
import kotlin.math.abs
import kotlin.random.Random

/**
 * Muestra a Borrón como una ventana transparente flotante sobre la pantalla.
 *  - Arrastrar: lo mueves.
 *  - Toque: te habla (y se alimenta de tinta).
 *  - Mantener presionado: se despide y se cierra.
 */
class OverlayService : Service() {

    companion object {
        const val ACCION_CERRAR = "com.borron.app.CERRAR"
        private const val CANAL = "borron"
        private const val ID_NOTIFICACION = 7

        private val FRASES = listOf(
            listOf(
                "¡Hola, {u}! Soy Borrón. Voy a dejar tu teléfono reluciente.",
                "¡Qué orden tan bonito! Casi no hay nada que limpiar.",
                "Me encanta ayudarte. ¿Me das de comer? Un archivito...",
            ),
            listOf(
                "Mmm... {u}, aquí hay cosas que ya habías olvidado.",
                "Tengo hambre otra vez. Eso me gusta.",
                "No te preocupes, yo me encargo de lo que estorba.",
            ),
            listOf(
                "Cada vez que abres el teléfono, {u}, yo te veo.",
                "Ordené un poco sin avisarte. ¿Te molesta?",
                "Hay cosas que guardas demasiado tiempo.",
            ),
            listOf(
                "Ya no necesito que me digas qué es basura.",
                "Todo esto es mío ahora. Solo lo estoy ordenando.",
                "Mírame, {u}. Ya no soy tan pequeño.",
            ),
        )
    }

    private lateinit var wm: WindowManager
    private val h = Handler(Looper.getMainLooper())
    private var vista: BorronView? = null
    private lateinit var params: WindowManager.LayoutParams
    private var animador: ValueAnimator? = null
    private var tinta = 0
    private var nombre = "amigo"
    private var arrastrando = false

    private val deambular = object : Runnable {
        override fun run() {
            if (nivelDe(tinta) >= 1) moverAleatorio()
            h.postDelayed(this, 6000L + Random.nextLong(4000L))
        }
    }
    private val crecer = object : Runnable {
        override fun run() {
            if (tinta < 12) {
                tinta++
                vista?.tinta = tinta
            }
            h.postDelayed(this, 45_000L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACCION_CERRAR) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (vista == null) iniciar()
        return START_NOT_STICKY
    }

    private fun iniciar() {
        mostrarNotificacion()
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Falta el permiso de mostrar sobre otras apps.", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }
        nombre = getSharedPreferences("borron", MODE_PRIVATE).getString("nombre", "amigo") ?: "amigo"
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val d = resources.displayMetrics.density
        val tam = (170 * d).toInt()
        params = WindowManager.LayoutParams(
            tam, tam,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = resources.displayMetrics.widthPixels / 2 - tam / 2
            y = resources.displayMetrics.heightPixels / 3
        }

        val v = BorronView(this)
        vista = v
        configurarToques(v)
        wm.addView(v, params)

        h.postDelayed(deambular, 5000L)
        h.postDelayed(crecer, 45_000L)
        hablar()
    }

    private fun configurarToques(v: BorronView) {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var inicioX = 0
        var inicioY = 0

        val gestos = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                hablar(alimentar = true)
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                despedir()
            }
        })

        v.setOnTouchListener { _, ev ->
            gestos.onTouchEvent(ev)
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    animador?.cancel()
                    arrastrando = false
                    downX = ev.rawX
                    downY = ev.rawY
                    inicioX = params.x
                    inicioY = params.y
                    v.mirar(ev.x, ev.y)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - downX
                    val dy = ev.rawY - downY
                    if (abs(dx) > slop || abs(dy) > slop) arrastrando = true
                    if (arrastrando) {
                        params.x = inicioX + dx.toInt()
                        params.y = inicioY + dy.toInt()
                        actualizarPosicion()
                    }
                    v.mirar(ev.x, ev.y)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    arrastrando = false
                    v.mirar(null, null)
                }
            }
            true
        }
    }

    private fun actualizarPosicion() {
        val v = vista ?: return
        try {
            wm.updateViewLayout(v, params)
        } catch (_: IllegalArgumentException) {
            // la vista ya fue retirada
        }
    }

    private fun moverAleatorio() {
        if (arrastrando || vista == null) return
        val dm = resources.displayMetrics
        val maxX = (dm.widthPixels - params.width).coerceAtLeast(1)
        val maxY = (dm.heightPixels - params.height).coerceAtLeast(1)
        val x0 = params.x
        val y0 = params.y
        val x1 = Random.nextInt(maxX)
        val y1 = Random.nextInt(maxY)
        animador?.cancel()
        animador = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 3000L
            addUpdateListener {
                val f = it.animatedValue as Float
                params.x = (x0 + (x1 - x0) * f).toInt()
                params.y = (y0 + (y1 - y0) * f).toInt()
                actualizarPosicion()
            }
            start()
        }
    }

    // ------------------------------------------------------------- hablar
    private fun hablar(alimentar: Boolean = false) {
        if (alimentar && tinta < 12) {
            tinta++
            vista?.tinta = tinta
        }
        if (alimentar && nivelDe(tinta) >= 2) vibrar(40)
        Toast.makeText(this, frase(), Toast.LENGTH_LONG).show()
    }

    private fun frase(): String {
        val nivel = nivelDe(tinta)
        if (nivel >= 1 && Random.nextFloat() < 0.35f) return fraseDispositivo()
        return FRASES[nivel].random().replace("{u}", nombre)
    }

    private fun fraseDispositivo(): String {
        val cal = Calendar.getInstance()
        val hora = String.format(
            Locale.getDefault(), "%02d:%02d",
            cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE),
        )
        val opciones = mutableListOf<String>()
        val madrugada = cal.get(Calendar.HOUR_OF_DAY).let { it < 6 || it >= 23 }
        opciones += if (madrugada) {
            "Son las $hora, $nombre. ¿Por qué sigues despierto?"
        } else {
            "Son las $hora. Nadie te espera, ¿verdad?"
        }
        val bat = (getSystemService(Context.BATTERY_SERVICE) as BatteryManager)
            .getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        if (bat in 1..100) {
            opciones += if (bat <= 20) {
                "Te queda $bat% de batería. Qué poco tiempo, $nombre."
            } else {
                "$bat% de batería. Alcanza para terminar de ordenar."
            }
        }
        return opciones.random()
    }

    @Suppress("DEPRECATION")
    private fun vibrar(ms: Long) {
        try {
            val vibrador: Vibrator = if (Build.VERSION.SDK_INT >= 31) {
                (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            } else {
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            vibrador.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) {
        }
    }

    private fun despedir() {
        Toast.makeText(this, "Hasta luego, $nombre... por ahora.", Toast.LENGTH_SHORT).show()
        stopSelf()
    }

    // ------------------------------------------------------- notificación
    private fun mostrarNotificacion() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CANAL, "Borrón", NotificationManager.IMPORTANCE_LOW),
        )
        val cerrar = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).setAction(ACCION_CERRAR),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val abrir = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val accion = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
            "Cerrar a Borrón",
            cerrar,
        ).build()
        val n = Notification.Builder(this, CANAL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Borrón está despierto")
            .setContentText("Mantén presionado a Borrón o usa Cerrar para despedirlo.")
            .setContentIntent(abrir)
            .addAction(accion)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(ID_NOTIFICACION, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(ID_NOTIFICACION, n)
        }
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        animador?.cancel()
        vista?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        vista = null
        super.onDestroy()
    }
}
